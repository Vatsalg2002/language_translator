const fromText=document.querySelector(".from-text");
toText=document.querySelector(".to-text");
selectTag=document.querySelectorAll("select");
exchangeIcon=document.querySelector(".exchange");
icons=document.querySelectorAll(".row i");


translateBtn=document.querySelector("button");



selectTag.forEach((tag,id)=>{
    // console.log(tag);  
    // printing all seclect tags
    for (const country_code in countries) {
        let selected;
        //selecting english to hindi as defaily transaltion
        if(id==0 && country_code=="en-GB"){ 
            selected="selected";
        }else if(id==1 && country_code=="hi-IN"){
            selected="selected";

        }
        let option=`<option value="${country_code}"${selected}>${countries[country_code]}</option>`;
        tag.insertAdjacentHTML("beforeend",option);
        //adding options to the selct menu
    }
});

//exchnage ka kam

exchangeIcon.addEventListener("click",()=>{
    //swapping vallue of each from nd to text
    let tempText=fromText.value;
    
    fromText.value=toText.value;
    
    toText.value=tempText;
    //swapping teh tags of language selected
    tempLang=selectTag[0].value;
    selectTag[0].value=selectTag[1].value;
    selectTag[1].value=tempLang;

});

//getting value of the enteretd text from .from class
translateBtn.addEventListener("click",()=>{
    let text=fromText.value;
    // console.log(text);
    translateFrom=selectTag[0].value,  //getting from value
    translateTo=selectTag[1].value;     //gettig to value
    //hanidng if not txt is specifed
    if(!text) return;
    toText.setAttribute("placeholder","Translating..."); 
    // console.log(text,translateFrom,translateTo)   //will print the codes of both the from and to lang
    let apiUrl=`https://api.mymemory.translated.net/get?q=${text}&langpair=${translateFrom}|${translateTo}`;
    //memory transalet api used here
    //fetchin data and converting it into json obj
    fetch(apiUrl).then(res=>res.json()).then(data=>{
        // console.log(data);
        toText.value=data.responseData.translatedText;
        //after fetchingg data chneg placelholder ot transation
        toText.setAttribute("placeholder","Translation"); 

    });

});


icons.forEach(icon =>{
    icon.addEventListener("click",({target})=>{
        //console.log(target); //prints the value of copy and volume up i tags
        if(target.classList.contains("fa-copy")){
            //if clicked has id of from ytehn front value will be copied else to value will be copied
            if(target.id=="from"){
                // console.log("from copy icon clickec");
                navigator.clipboard.writeText(fromText.value);
            }else{
                // console.log("to copy icon clickec");
                navigator.clipboard.writeText(toText.value);
            }
        }else{
            // console.log("specch icon clickec");
            let utterance;
            if(target.id=="from"){
                // console.log("from speech icon clickec");
                utterance=new SpeechSynthesisUtterance(fromText.value);
                utterance.lang=selectTag[0].value; //setting uttarance lang value
            }else{
                // console.log("to speech icon clickec");
                utterance=new SpeechSynthesisUtterance(toText.value);
                utterance.lang=selectTag[1].value;
                
            }
            speechSynthesis.speak(utterance)

        }
    });
})